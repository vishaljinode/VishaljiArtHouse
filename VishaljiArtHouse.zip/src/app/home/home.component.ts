import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  tshirts = [
    {
      title: 'Stylish Cotton T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 599,
      image: 'https://via.placeholder.com/300'
    },
    {
      title: 'Graphic Design T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 799,
      image: 'https://via.placeholder.com/300'
    },
    {
      title: 'Classic Black T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 499,
      image: 'https://via.placeholder.com/300'
    },
    {
      title: 'Stylish Cotton T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 599,
      image: 'https://via.placeholder.com/300'
    },
    {
      title: 'Graphic Design T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 799,
      image: 'https://via.placeholder.com/300'
    },
    {
      title: 'Classic Black T-shirt',
      description: 'T-shirt with an eye-catching graphic print, perfect for the trendy you.',
      price: 499,
      image: 'https://via.placeholder.com/300'
    }
  ];

  orderFromWhatsApp(tshirt: any) {
    const message = `Hello, I would like to order the ${tshirt.title} for ₹${tshirt.price}.`;
    const link = `https://wa.me/+919664720473?text=${encodeURIComponent(message)}`;
    window.open(link, '_blank');
  }
}
